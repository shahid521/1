# Dara Helper Tool

Dara Helper Tool is an Android utility application featuring an AMOLED dark UI, dynamic Termux terminal integration, custom obfuscated package sync (.ba / .lm dual format), and remote admin telemetry control.

## Project Structure
- `.github/workflows/build-apk.yml` - GitHub Actions CI/CD to build APK automatically.
- `admin_panel/` - Flask Admin Web Server and device telemetry control dashboard.
- `backend_tools/` - Python obfuscation & file splitter tool (.gz -> .ba + .lm).
- `android_app/` - Complete Jetpack Compose + Termux Android Gradle Project.

## How to Build APK via GitHub Actions
1. Push this repository to GitHub.
2. Go to the **Actions** tab in your repository.
3. The **Build Dara Helper Tool APK** workflow will trigger automatically.
4. Download `DaraHelperTool-Debug-APK` from the workflow run artifacts.
