# Proguard rules for Dara Helper Tool
-keep class com.termux.** { *; }
-keepclassmembers class com.termux.** { *; }
